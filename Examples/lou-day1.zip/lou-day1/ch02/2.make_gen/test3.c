#include "a.h"
#include "b.h"
#include "c.h"

void func2()
{
   int n=NO1+NO2;
   printf("test3(%d)\n", n);
}
