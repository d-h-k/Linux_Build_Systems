#include "a.h"
#include "c.h"

void func2();

int main()
{
   int n=NO2;
   printf("exam3(%d)\n", n);
   func2();
   return 0;
}
