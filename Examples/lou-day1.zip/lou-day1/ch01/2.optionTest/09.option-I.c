#include <stdio.h>

#include "mydefine.h"

int main(void)
{
    int lv1, lv2, lv3=30;

    lv1 = NO1;
    lv2 = NO2;
    printf("lv1:%d,lv2:%d,lv3:%d\n", lv1,lv2,lv3);
    printf("Main End...\n");

    return 0;
}
