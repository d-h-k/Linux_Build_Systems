#include <stdio.h>
#include <stdlib.h>

int f1(int x)
{
	return ++x;
}

int f2(int x)
{
	return --x;
}
