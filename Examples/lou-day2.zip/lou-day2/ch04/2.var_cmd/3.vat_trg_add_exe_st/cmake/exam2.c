#include "a.h"
#include "b.h"

void func1();

int main()
{
   int n=NO1;
   printf("exam2(%d)\n", n);
   func1();
   return 0;
}
