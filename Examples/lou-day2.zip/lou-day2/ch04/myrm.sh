#!/bin/bash
rm CMakeCache.txt
rm cmake_install.cmake
rm Makefile
rm -rf CMakeFiles
