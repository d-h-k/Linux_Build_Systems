/* app.c */

#include <stdio.h>
#include "testlib.h"

int main(void)
{
    printf("max(5, 2) : %d\n", max(5, 2));
    printf("min(5, 2) : %d\n", min(5, 2));

    return 0;
}
