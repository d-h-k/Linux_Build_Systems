#include "a.h"
#include "b.h"
#include "c.h"

void func3()
{
   int n=NO1+NO2;
   printf("test4(%d)\n", n);
}
