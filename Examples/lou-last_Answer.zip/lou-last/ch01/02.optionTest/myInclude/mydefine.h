#define	NO1	10
#define	NO2	20

